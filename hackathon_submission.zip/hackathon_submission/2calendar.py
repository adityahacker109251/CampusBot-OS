import os
import cv2
import time
import torch
import numpy as np
import pymongo
import speech_recognition as sr
from dotenv import load_dotenv
from datetime import datetime, timedelta
from sentence_transformers import SentenceTransformer
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import Flow
from google.auth.transport.requests import Request
from torch import nn, optim
from torch.nn import Transformer
import torch.nn.functional as F
from pymongo import MongoClient
from typing import Dict, List, Optional
import face_recognition
from together import Together
from gtts import gTTS
import pyttsx3
from pygame import mixer
import io
import requests
from textblob import TextBlob
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from pytube import YouTube
import dns.resolver
import sys
import random
from bson import ObjectId
import webbrowser
import subprocess
import signal
import math
import urllib.parse

# Function to print status messages with better visibility
def print_status_box(message, status_type="info"):
    """Print a status message in a styled box for better visibility
    
    Args:
        message: The message to display
        status_type: info, success, warning, error, or listening
    """
    # This function has been removed in favor of minimal terminal output
    pass

# Set a timeout for DNS queries
dns.resolver.default_resolver = dns.resolver.Resolver(configure=False)
dns.resolver.default_resolver.nameservers = ['8.8.8.8', '8.8.4.4']
dns.resolver.default_resolver.timeout = 5
dns.resolver.default_resolver.lifetime = 5

# Load environment variables
load_dotenv()
MONGO_URI = os.getenv("MONGO_URI")
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID")
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET")
TOGETHER_API_KEY = os.getenv("TOGETHER_API_KEY")
WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")
YOUTUBE_API_KEY = os.getenv("YOUTUBE_API_KEY")
SPLINE_URL = os.getenv("SPLINE_URL", "https://my.spline.design/sphereassistantdemocommunitycopy-19d5d018e90bae9c7a94af8741bec6f9/")
# Get the current directory
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
CONNECTOR_PATH = os.path.join(CURRENT_DIR, "public", "spline_connector.html")

# Database setup
client = MongoClient(MONGO_URI)
db = client["NeuroAI"]
users = db.users

# Hyperparameters
MEMORY_DIM = 512
TEMPORAL_DECAY = 0.15
SIMILARITY_THRESHOLD = 0.35
MAX_CONVERSATION_HISTORY = 20
INACTIVITY_TIMEOUT = 30  # 30 seconds of inactivity before sleep
WAKE_WORD_TIMEOUT = 1    # 1 second listening chunks in sleep mode
MEMORY_IMPORTANCE_WEIGHTS = {
    'fact': 1.2,
    'preference': 1.5,
    'trivial': 0.8
}

class SplineManager:
    """Handles Spline 3D character animations and communication"""
    def __init__(self):
        self.server_process = None
        self.current_state = "idle"
        self.current_text = ""
        self.state_map = {
            "idle": self._trigger_idle,
            "talking": self._trigger_talking,
            "listening": self._trigger_listening,
            "sleeping": self._trigger_sleeping
        }
        self.is_initialized = False
        
    def initialize(self):
        """Start server and open Spline connector in browser"""
        if self.is_initialized:
            return
            
        try:
            # Kill any existing Python processes on port 8000
            print("Starting Spline interface...")
            self._kill_processes_on_port(8000)
            
            # Make sure the server directory exists
            server_path = os.path.join(CURRENT_DIR, "public", "server.py")
            if not os.path.exists(server_path):
                print(f"Server script not found at {server_path}")
                # Create directory if it doesn't exist
                os.makedirs(os.path.join(CURRENT_DIR, "public"), exist_ok=True)
                return
                
            # Run the server in a separate process with better error handling
            try:
                # Use a more robust way to start the subprocess
                self.server_process = subprocess.Popen(
                    [sys.executable, server_path],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
                )
                
                # Wait a moment for the server to start
                time.sleep(3)
                
                # Check if the process is still running
                if self.server_process.poll() is not None:
                    # Process exited, get error output
                    stdout, stderr = self.server_process.communicate()
                    print(f"Server failed to start: {stderr}")
                    return
                    
                # Try to connect to verify the server is running
                try:
                    test_response = requests.get("http://localhost:8000/", timeout=2)
                    if test_response.status_code == 200:
                        print("Web interface ready")
                        self.is_initialized = True
                except requests.exceptions.RequestException as e:
                    print(f"Could not connect to server: {e}")
                    return
                    
                print("Spline connector started")
                self.is_initialized = True
                
            except Exception as subprocess_error:
                print(f"Error starting subprocess: {subprocess_error}")
                return
                
        except Exception as e:
            print(f"Error starting Spline connector: {e}")
            self.is_initialized = False
            
    def _kill_processes_on_port(self, port):
        """Kill any processes running on the specified port"""
        try:
            if os.name == 'nt':  # Windows
                # Find PID using port
                result = subprocess.run(['netstat', '-ano', '|', 'findstr', f':{port}'], 
                                       shell=True, capture_output=True, text=True)
                for line in result.stdout.splitlines():
                    if f':{port}' in line and 'LISTENING' in line:
                        parts = line.strip().split()
                        if len(parts) > 4:
                            pid = parts[4]
                            print(f"Killing process {pid} on port {port}")
                            subprocess.run(['taskkill', '/F', '/PID', pid], 
                                          capture_output=True)
            else:  # Linux/Mac
                result = subprocess.run(['lsof', '-i', f':{port}'], 
                                       capture_output=True, text=True)
                for line in result.stdout.splitlines()[1:]:  # Skip header
                    parts = line.strip().split()
                    if len(parts) > 1:
                        pid = parts[1]
                        print(f"Killing process {pid} on port {port}")
                        subprocess.run(['kill', '-9', pid], 
                                      capture_output=True)
        except Exception as e:
            print(f"Error killing processes on port {port}: {e}")
            
    def update_state(self, new_state: str, text=""):
        """Update character animation state and display text"""
        try:
            if new_state not in self.state_map:
                raise ValueError(f"Invalid state: {new_state}")
            
            # Update text if provided
            if text:
                # Keep text as-is, don't add emoji yet (done in the trigger methods)
                self.current_text = text
            
            if new_state != self.current_state or text:
                self.state_map[new_state]()
                self.current_state = new_state
        except Exception as e:
            print(f"Error updating Spline state: {e}")
            
    def _trigger_idle(self):
        """Set idle animation state"""
        self._update_spline_text("")  # Clear text in idle state

    def _trigger_talking(self):
        """Set talking animation state and update text with emoji"""
        # Add speaking emoji to the text if not already there
        if self.current_text and not self.current_text.startswith("🔊"):
            self.current_text = f"🔊 \"{self.current_text}\""
        self._update_spline_text(self.current_text)

    def _trigger_listening(self):
        """Set listening animation state and show listening message with emoji"""
        self._update_spline_text("🎤 Listening...")

    def _trigger_sleeping(self):
        """Set sleeping animation state with emoji"""
        self._update_spline_text("💤 Zzz... Say 'wake up' to activate")
            
    def cleanup(self):
        """Clean up resources"""
        if self.server_process:
            print("Stopping Spline server...")
            try:
                # Try graceful shutdown first
                if os.name == 'nt':  # Windows
                    self.server_process.send_signal(signal.CTRL_BREAK_EVENT)
                else:  # Unix
                    self.server_process.send_signal(signal.SIGTERM)
                    
                # Wait for a bit
                time.sleep(1)
                
                # If still running, force kill
                if self.server_process.poll() is None:
                    self.server_process.terminate()
                    time.sleep(0.5)
                
                # If STILL running, really force kill
                if self.server_process.poll() is None:
                    self.server_process.kill()
                    
                self.server_process = None
                print("Server process terminated successfully")
            except Exception as e:
                print(f"Error stopping server: {e}")
                # Last resort: kill all Python processes on port 8000
                self._kill_processes_on_port(8000)
            
    def _update_spline_text(self, text):
        """Send text to the Spline scene via URL parameter"""
        if not self.is_initialized:
            # Try to re-initialize if not initialized
            self.initialize()
            if not self.is_initialized:
                return
            
        try:
            # Check if server is still running
            if self.server_process and self.server_process.poll() is not None:
                print("Server process has terminated, restarting...")
                self.is_initialized = False
                self.initialize()
                if not self.is_initialized:
                    return
            
            # Encode text for URL
            encoded_text = urllib.parse.quote(text)
            if len(encoded_text) > 0:
                # Use requests with retry
                for attempt in range(3):
                    try:
                        url = f"http://localhost:8000/update?text={encoded_text}&state={self.current_state}"
                        requests.get(url, timeout=0.5)  # Non-blocking request
                        break
                    except requests.exceptions.RequestException as e:
                        if attempt < 2:  # Try twice more
                            time.sleep(0.2)
                        else:
                            print(f"Failed to send text to web interface: {e}")
        except Exception as e:
            # Log all other errors
            print(f"Error updating Spline text: {e}")
            
    def display_user_speech(self, text):
        """Display what the user is saying with emoji"""
        if text:
            self._update_spline_text(f"👤 \"{text}\"")

class NeuroMemoryCore(nn.Module):
    """User-specific neural memory network"""
    def __init__(self, user_id: str):
        super().__init__()
        self.user_id = user_id
        self.transformer = Transformer(
            d_model=MEMORY_DIM,
            nhead=8,
            num_encoder_layers=2,
            num_decoder_layers=2,
            batch_first=True
        )
        self.decay = nn.Parameter(torch.tensor(TEMPORAL_DECAY))
        self.projection = nn.Linear(768, MEMORY_DIM)
        
        user_data = users.find_one({"_id": user_id})
        if user_data and "memory_weights" in user_data:
            self.load_state_dict(user_data["memory_weights"])
            
    def temporal_decay(self, memory: torch.Tensor, timestamp: datetime) -> torch.Tensor:
        hours = (datetime.now() - timestamp).total_seconds() / 3600
        return memory * torch.exp(-self.decay * hours)
    
    def forward(self, query: torch.Tensor, memories: List[Dict]) -> torch.Tensor:
        if not memories:
            return query
            
        memory_tensors = [
            self.projection(torch.tensor(m["embedding"]))
            for m in memories
        ]
        
        memory_tensors = [
            self.temporal_decay(memory, m["timestamp"])
            for memory, m in zip(memory_tensors, memories)
        ]
        
        memory_matrix = torch.stack(memory_tensors)
        if memory_matrix.size(-1) != MEMORY_DIM:
            memory_matrix = F.pad(memory_matrix, (0, MEMORY_DIM - memory_matrix.size(-1)))
        
        query = self.projection(query)
        query = query.unsqueeze(0).unsqueeze(0)
        memory_matrix = memory_matrix.unsqueeze(0)
        
        processed = self.transformer(query, memory_matrix, memory_matrix)
        return processed.squeeze(0).squeeze(0)
    
    def save(self):
        users.update_one(
            {"_id": self.user_id},
            {"$set": {"memory_weights": self.state_dict()}}
        )

class YouTubeMusicClient:
    def __init__(self, api_key: str):
        self.youtube = build("youtube", "v3", developerKey=api_key)
        self.current_stream = None

    def search_music(self, query: str) -> Optional[str]:
        try:
            clean_query = query.replace("play", "").replace("music", "").strip()
            request = self.youtube.search().list(
                q=f"{clean_query} official music",
                part="snippet",
                type="video",
                maxResults=1,
                videoCategoryId=10,
                videoDuration="medium"
            )
            response = request.execute()
            if response.get("items"):
                return f"https://www.youtube.com/watch?v={response['items'][0]['id']['videoId']}"
            return None
        except Exception as e:
            print(f"YouTube API Error: {str(e)}")
            return None

    def play_music(self, url: str):
        """Play music from YouTube URL with proper error handling and cleanup."""
        try:
            if not mixer.get_init():
                mixer.init(frequency=44100, size=-16, channels=2, buffer=4096)
            
            if mixer.music.get_busy():
                mixer.music.stop()
                time.sleep(0.5)

            def on_progress(stream, chunk, bytes_remaining):
                total_size = stream.filesize
                bytes_downloaded = total_size - bytes_remaining
                percent = (bytes_downloaded / total_size) * 100
                print(f"\rDownloading: {percent:.1f}% complete", end='', flush=True)

            def on_complete(stream, file_path):
                print(f"\nDownload complete: {file_path}")

            yt = YouTube(
                url,
                on_progress_callback=on_progress,
                on_complete_callback=on_complete,
                use_oauth=True,
                allow_oauth_cache=True
            )

            audio_stream = yt.streams.filter(
                only_audio=True,
                file_extension='mp4'
            ).order_by('abr').desc().first()

            if not audio_stream:
                raise Exception("No suitable audio stream found")

            temp_file = "temp_music.mp4"
            print("Starting download...")
            audio_stream.download(filename=temp_file)
            
            mixer.music.load(temp_file)
            mixer.music.set_volume(0.8)
            print("Starting playback...")
            mixer.music.play()

            # Simplified playback monitoring
            while mixer.music.get_busy():
                time.sleep(0.1)

            mixer.music.unload()
            try:
                os.remove(temp_file)
                print("Temporary file removed")
            except OSError as e:
                print(f"Error removing temp file: {e}")

        except Exception as e:
            print(f"Music playback error: {str(e)}")
            try:
                if 'temp_file' in locals() and os.path.exists(temp_file):
                    os.remove(temp_file)
            except:
                pass
            raise RuntimeError(f"Could not play music: {str(e)}")

class AICompanion:
    
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.memory_model = SentenceTransformer("all-mpnet-base-v2")
        self.active_users: Dict[str, NeuroMemoryCore] = {}
        mixer.init()
        self.youtube_music = YouTubeMusicClient(YOUTUBE_API_KEY)
        self.pyttsx3_engine = pyttsx3.init()
        self.last_activity = time.time()
        self.sleep_mode = False
        self.current_user = None
        self.memory_cache = {}
        self.spline = SplineManager()
        self.spline.initialize()
        self._preload_models()
        
        self.pyttsx3_engine.setProperty('rate', 180)
        self.pyttsx3_engine.setProperty('volume', 0.9)
        self.character_state = "idle"

        # Ensure personal_facts field exists for all users
        users.update_many(
            {"personal_facts": {"$exists": False}},
            {"$set": {"personal_facts": []}}
        )
        
        # Display initialization message with minimal info
        print("✅ AI Companion ready")
        print("🔑 Wake word: 'wake up'")

    def _preload_models(self):
        """Preload models to reduce latency during first use."""
        print("Preloading models...")
        
        # Create a more realistic dummy image for better model initialization
        dummy_image = np.zeros((300, 300, 3), dtype=np.uint8)
        # Add some random features to better initialize the model
        cv2.circle(dummy_image, (150, 150), 60, (100, 150, 200), -1)
        cv2.rectangle(dummy_image, (100, 80), (200, 220), (150, 100, 200), -1)
        
        # Preload face detection and encoding
        print("Initializing face recognition...")
        face_locations = face_recognition.face_locations(
            dummy_image, 
            model="hog", 
            number_of_times_to_upsample=1
        )
        if face_locations:
            face_recognition.face_encodings(dummy_image, face_locations)
            
        # Preload sentence transformer
        print("Initializing language model...")
        self.memory_model.encode("warmup")
        
        # Initialize speech recognition
        print("Optimizing speech recognition...")
        self._optimize_speech_recognition()
        
        print("Models ready")

    def _optimize_speech_recognition(self):
        """Configure speech recognition for optimal performance."""
        try:
            # Initialize microphone and recognizer to cache their setup time
            with sr.Microphone() as source:
                # Adjust for ambient noise once to initialize audio levels
                self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
                print("Ambient noise level measured")
                
                # Set good default values for faster recognition
                self.recognizer.pause_threshold = 0.5  # Shorter pause detection
                self.recognizer.energy_threshold = 300  # Starting sensitivity
                self.recognizer.dynamic_energy_threshold = True  # Auto-adjust to environment
                self.recognizer.dynamic_energy_adjustment_ratio = 1.5  # Faster adjustment
                
                # Try a quick recognition to cache necessary resources
                try:
                    print("Say something to initialize speech recognition...")
                    audio = self.recognizer.listen(source, timeout=2, phrase_time_limit=2)
                    try:
                        # Try to recognize (will likely fail, but will initialize)
                        self.recognizer.recognize_google(audio)
                    except:
                        pass
                        
                    # Try to load sphinx for offline recognition
                    try:
                        from pocketsphinx import get_model_path
                        print("Offline recognition initialized")
                    except:
                        print("Offline recognition not available (optional)")
                    
                except sr.WaitTimeoutError:
                    print("No speech detected during initialization (this is OK)")
                    
        except Exception as e:
            print(f"Speech recognition optimization warning: {e}")
            # Non-fatal error, system will still work

    def check_inactivity(self):
        """Check if the user has been inactive for more than the timeout period."""
        inactive_time = time.time() - self.last_activity
        if inactive_time > INACTIVITY_TIMEOUT:
            if not self.sleep_mode:
                print("💤 Entering sleep mode")
                self.speak("I'm going to sleep now. Say 'wake up' to wake me up.", force=True)
                self.sleep_mode = True
                self.spline.update_state("sleeping")
            return True
        return False

    def update_activity(self):
        """Update the last activity timestamp and wake up from sleep mode if necessary."""
        self.last_activity = time.time()
        if self.sleep_mode:
            self.sleep_mode = False
            self.spline.update_state("idle")
            self.speak("Hello! I'm awake now. How can I help you?", force=True)

    def _listen_for_wake_word(self):
        """Optimized wake word detection for faster, more accurate triggering."""
        wake_word = self.current_user.get("wake_word", "wake up") if self.current_user else "wake up"
        
        # Update Spline state - emoji is added in _trigger_sleeping method
        self.spline.update_state("sleeping")
        
        # Simple console indicator (minimal)
        print("💤 Sleeping (say 'wake up')")
        
        # Set more sensitive parameters for wake word detection
        self.recognizer.pause_threshold = 0.3  # Very short pauses for wake word
        self.recognizer.energy_threshold = 280  # More sensitive while sleeping
        self.recognizer.dynamic_energy_threshold = True
        
        try:
            with sr.Microphone() as source:
                # Shorter ambient noise adjustment (0.3s)
                self.recognizer.adjust_for_ambient_noise(source, duration=0.3)
                
                # Use shorter timeout and phrase time for wake word
                audio = self.recognizer.listen(source, timeout=2, phrase_time_limit=3)
                
            # Try offline recognition first for wake word - faster response
            try:
                # Configure sphinx to specifically listen for wake word
                text = self.recognizer.recognize_sphinx(
                    audio,
                    keyword_entries=[(wake_word, 0.8)]  # Higher weight (0.8) for wake word
                ).lower()
                
                if wake_word.lower() in text.lower():
                    print(f"🔔 Wake word detected offline: \"{text}\"")
                    self.spline.display_user_speech(f"'{wake_word}'")
                    self.update_activity()
                    return text
            except:
                # If offline recognition fails, try online recognition
                pass
                
            # Fallback to Google for better accuracy
            text = self.recognizer.recognize_google(audio).lower()
            
            if wake_word.lower() in text.lower():
                print(f"🔔 Wake word detected: \"{text}\"")
                # Display what user said on Spline
                self.spline.display_user_speech(text)
                self.update_activity()
                return text
            else:
                return ""
                
        except Exception as e:
            if isinstance(e, sr.WaitTimeoutError) or isinstance(e, sr.UnknownValueError):
                # Don't log timeout errors as they're expected
                pass
            else:
                print(f"Wake word error: {str(e)}")
            return ""

    def recognize_user(self) -> Optional[Dict]:
        """Recognize the user via face recognition with video enhancement for better detection."""
        try:
            # Show searching indicator on Spline
            self.spline.update_state("idle", "Searching for face - please look at the camera")
            
            # Open camera
            cap = cv2.VideoCapture(0)
            
            # Set higher resolution for better detection
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)  # Full HD width
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080) # Full HD height
            cap.set(cv2.CAP_PROP_FPS, 30)            # Higher FPS
            
            # Capture frame
            ret, frame = cap.read()
            cap.release()
            
            if not ret:
                print("Error: Could not capture frame from camera.")
                self.spline.update_state("idle", "Could not access camera. Please check permissions.")
                return None
            
            self.spline.update_state("idle", "Processing image...")
            
            # Apply video enhancement (similar to Google Meet enhancement)
            # 1. Apply brightness and contrast enhancement
            alpha = 1.2  # Contrast control (1.0 means no change)
            beta = 10    # Brightness control (0 means no change)
            enhanced_frame = cv2.convertScaleAbs(frame, alpha=alpha, beta=beta)
            
            # 2. Apply noise reduction
            enhanced_frame = cv2.fastNlMeansDenoisingColored(enhanced_frame, None, 10, 10, 7, 21)
            
            # 3. Apply sharpening
            kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
            enhanced_frame = cv2.filter2D(enhanced_frame, -1, kernel)
            
            # 4. Increase saturation slightly (in HSV space)
            hsv = cv2.cvtColor(enhanced_frame, cv2.COLOR_BGR2HSV)
            hsv[:,:,1] = hsv[:,:,1] * 1.2  # Increase saturation by 20%
            hsv[:,:,1] = np.clip(hsv[:,:,1], 0, 255)  # Ensure values are in valid range
            enhanced_frame = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
            
            self.spline.update_state("idle", "Looking for faces...")
            
            # Detect faces with more aggressive upsampling for distance detection
            face_locations = face_recognition.face_locations(
                enhanced_frame, 
                model="hog",
                number_of_times_to_upsample=3  # Higher value to detect smaller/distant faces
            )
            
            if not face_locations:
                print("No faces detected.")
                self.spline.update_state("idle", "No faces detected. Please try again.")
                return None
                
            print(f"Detected {len(face_locations)} faces.")
            self.spline.update_state("idle", f"Found {len(face_locations)} face(s)! Processing...")
            
            # Sort face locations by size (largest first) to prioritize closer faces
            face_locations.sort(key=lambda loc: (loc[2] - loc[0]) * (loc[1] - loc[3]), reverse=True)
            
            # Get encodings for the enhanced frame
            encodings = face_recognition.face_encodings(
                enhanced_frame, 
                face_locations,
                num_jitters=2,  # Increase accuracy with more jitters
                model="large"   # Use large model for better accuracy at distance
            )
            
            if not encodings:
                print("No face encodings found.")
                self.spline.update_state("idle", "Face detected but couldn't extract features.")
                return None
                
            # Check against all users with a more tolerant threshold for distance
            self.spline.update_state("idle", "Checking user database...")
            for user in users.find():
                if "face_encoding" not in user:
                    continue
                    
                stored_enc = np.array(user["face_encoding"])
                # Increased tolerance for better distance recognition
                if face_recognition.compare_faces([stored_enc], encodings[0], tolerance=0.65)[0]:
                    self.spline.update_state("idle", f"Welcome back, {user['name']}!")
                    return user
            
            # If we found a face but no match, this is likely a new user
            self.spline.update_state("idle", "New user detected!")
            self.speak("New user! Please say your full name.", force=True)
            name = self.listen().strip()
            if not name:
                print("No name provided.")
                self.spline.update_state("idle", "Registration canceled.")
                return None
                
            new_user = {
                "_id": name.lower().replace(" ", "_"),
                "name": name,
                "face_encoding": encodings[0].tolist(),
                "memories": [],
                "conversation_log": [],
                "personal_facts": [],
                "calendar_tokens": None,
                "neural_weights": None,
                "created_at": datetime.now(),
                "language_preference": "english",
                "wake_word": "wake up"  # Fixed default wake word
            }
            users.insert_one(new_user)
            self.spline.update_state("idle", f"Welcome, {name}!")
            return new_user
                    
        except Exception as e:
            print(f"Face Recognition Error: {str(e)}")
            self.spline.update_state("idle", "Face recognition error. Please try again.")
            return None

    def store_personal_fact(self, user: Dict, fact_type: str, value: str):
        """Store a personal fact about the user with proper categorization."""
        try:
            # First check if this fact type already exists
            existing_fact = users.find_one(
                {"_id": user["_id"], "personal_facts.type": fact_type},
                {"personal_facts.$": 1}
            )
            
            if existing_fact:
                # Update existing fact
                users.update_one(
                    {"_id": user["_id"], "personal_facts.type": fact_type},
                    {
                        "$set": {
                            "personal_facts.$.value": value,
                            "personal_facts.$.last_updated": datetime.now()
                        }
                    }
                )
            else:
                # Add new fact
                users.update_one(
                    {"_id": user["_id"]},
                    {
                        "$push": {
                            "personal_facts": {
                                "type": fact_type,
                                "value": value,
                                "created_at": datetime.now(),
                                "last_updated": datetime.now()
                            }
                        }
                    }
                )
                
            # Update local user object
            if "personal_facts" not in user:
                user["personal_facts"] = []
                
            # Remove if exists
            user["personal_facts"] = [f for f in user["personal_facts"] if f["type"] != fact_type]
            user["personal_facts"].append({
                "type": fact_type,
                "value": value,
                "last_updated": datetime.now()
            })
            
        except Exception as e:
            print(f"Error storing personal fact: {str(e)}")

    def get_personal_fact(self, user: Dict, fact_type: str) -> Optional[str]:
        """Retrieve a personal fact about the user."""
        try:
            # Check local cache first
            if "personal_facts" in user:
                for fact in user["personal_facts"]:
                    if fact["type"] == fact_type:
                        return fact["value"]
                        
            # If not found locally, check database
            fresh_user = users.find_one(
                {"_id": user["_id"]},
                {"personal_facts": {"$elemMatch": {"type": fact_type}}}
            )
            
            if fresh_user and "personal_facts" in fresh_user:
                fact = fresh_user["personal_facts"][0]
                # Update local cache
                if "personal_facts" not in user:
                    user["personal_facts"] = []
                user["personal_facts"].append(fact)
                return fact["value"]
                
            return None
        except Exception as e:
            print(f"Error retrieving personal fact: {str(e)}")
            return None

    def speak(self, text: str, force=False):
        """Speak the given text and display it on Spline."""
        if self.sleep_mode and not force:
            return

        # Simple console indicator (minimal)
        print(f"🔊 \"{text}\"")
        
        self.update_activity()
        
        # Update Spline with text and state
        # Don't add emoji here, let the _trigger_talking method handle it
        self.spline.update_state("talking", text)

        try:
            user = self.current_user or {}
            lang_pref = user.get("language_preference", "english")
            
            if lang_pref == "english":
                self.pyttsx3_engine.say(text)
                self.pyttsx3_engine.runAndWait()
            else:
                tts = gTTS(text, lang="hi" if lang_pref == "hindi" else "en")
                with io.BytesIO() as audio_bytes:
                    tts.write_to_fp(audio_bytes)
                    audio_bytes.seek(0)
                    mixer.music.load(audio_bytes)
                    mixer.music.play()
                    while mixer.music.get_busy():
                        pass
        except Exception as e:
            print(f"Speech error: {str(e)}")

        self.spline.update_state("idle")

    def listen(self, retries=3) -> str:
        """Listen to user input with faster and more accurate speech recognition."""
        if self.sleep_mode:
            return self._listen_for_wake_word()
        
        # Update Spline - emoji is added in _trigger_listening method
        self.spline.update_state("listening")
        
        # Simple console indicator (minimal)
        print("🎤 Listening...")

        # Set recognition parameters for faster recognition
        self.recognizer.pause_threshold = 0.5  # Shorter pause detection
        self.recognizer.energy_threshold = 300  # More sensitive for better pickup
        self.recognizer.dynamic_energy_threshold = True  # Automatic adjustment to ambient noise
        self.recognizer.dynamic_energy_adjustment_ratio = 1.5  # Faster adjustment

        # Try Google's streaming recognition first (faster)
        for attempt in range(retries):
            try:
                with sr.Microphone() as source:
                    # Shorter ambient noise adjustment (0.5s instead of 1s)
                    self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
                    
                    # Increase sensitivity slightly based on attempt number
                    if attempt > 0:
                        self.recognizer.energy_threshold *= 0.9  # More sensitive with each retry
                    
                    # Shorter timeout for faster processing
                    audio = self.recognizer.listen(source, timeout=3, phrase_time_limit=8)
                
                # Try Google first (fastest and most accurate)
                text = self.recognizer.recognize_google(audio)
                
                # If successful, display and return text
                print(f"👤 \"{text}\"")
                self.spline.display_user_speech(text)
                return text.strip()
                
            except sr.WaitTimeoutError:
                print("No speech detected, retrying..." if attempt < retries - 1 else "No speech detected")
                continue
            except sr.UnknownValueError:
                # Try a second recognition method if Google fails
                try:
                    # Fallback to Sphinx (offline) for difficult audio
                    text = self.recognizer.recognize_sphinx(audio)
                    if text and len(text) > 2:  # Only accept if we got something meaningful
                        print(f"👤 \"{text}\" (via fallback recognition)")
                        self.spline.display_user_speech(text)
                        return text.strip()
                except:
                    print("Speech not understood, retrying..." if attempt < retries - 1 else "Speech not understood")
                continue
            except sr.RequestError as e:
                print(f"Recognition service error: {str(e)}")
                # Try offline recognition as a fallback
                try:
                    text = self.recognizer.recognize_sphinx(audio)
                    print(f"👤 \"{text}\" (via offline recognition)")
                    self.spline.display_user_speech(text)
                    return text.strip()
                except:
                    pass
                continue
            except Exception as e:
                print(f"Error: {str(e)}")
                continue
        return ""

    def handle_data_deletion(self, user: Dict):
        """Handle the deletion of user data after confirmation."""
        self.speak("Permanently delete all your data? This cannot be undone.")
        confirmation = self.listen().lower()
        
        if "yes" in confirmation or "confirm" in confirmation:
            try:
                users.delete_one({"_id": user["_id"]})
                self.speak("All data deleted successfully")
                self.current_user = None
            except Exception as e:
                print(f"Data Deletion Error: {str(e)}")
                self.speak("Failed to delete data")
        else:
            self.speak("Data deletion cancelled")

    def check_reminders(self, user: Dict) -> bool:
        """Check and notify the user about any pending reminders."""
        try:
            now = datetime.now()
            fresh_user = users.find_one({"_id": user["_id"]})
            if not fresh_user:
                return False
                
            reminders = fresh_user.get("reminders", [])
            if not reminders:
                return False
                
            processed_reminders = []
            reminder_found = False
            
            for reminder in reminders:
                if now >= reminder["time"]:
                    self.speak(f"Reminder: {reminder['text']}")
                    reminder_found = True
                    
                    if reminder.get("recurring"):
                        next_time = now + timedelta(days=reminder["recurring"])
                        users.update_one(
                            {"_id": user["_id"], "reminders._id": reminder["_id"]},
                            {"$set": {"reminders.$.time": next_time}}
                        )
                    else:
                        processed_reminders.append(reminder["_id"])
                elif now + timedelta(minutes=5) >= reminder["time"]:
                    self.speak(f"Upcoming reminder at {reminder['time'].strftime('%I:%M %p')}: {reminder['text']}")
                    reminder_found = True
            
            if processed_reminders:
                users.update_one(
                    {"_id": user["_id"]},
                    {"$pull": {"reminders": {"_id": {"$in": processed_reminders}}}}
                )
                
            return reminder_found
            
        except Exception as e:
            print(f"Reminder Error: {str(e)}")
            self.speak("Had trouble checking reminders")
            return False

    def has_reminders(self, user: Dict) -> bool:
        """Check if user has any active reminders."""
        try:
            fresh_user = users.find_one({"_id": user["_id"]})
            return bool(fresh_user.get("reminders", []))
        except Exception as e:
            print(f"Reminder Check Error: {str(e)}")
            return False

    def generate_response(self, user: Dict, query: str) -> str:
        """Generate a contextual response with improved semantic understanding."""
        try:
            query_lower = query.lower()
            
            # Analyze query intent for better context understanding
            is_question = any(q in query_lower for q in ["?", "what", "when", "where", "who", "why", "how", "can you", "could you"])
            is_personal = any(p in query_lower for p in ["i ", "my ", "me ", "i'm ", "i've ", "i'll ", "mine"])
            is_memory_related = any(m in query_lower for m in ["remember", "forget", "remind", "recall", "memory", "told", "said", "mentioned"])
            is_preference = any(p in query_lower for p in ["like", "love", "hate", "prefer", "favorite", "enjoy"])
            
            # Handle age-related queries
            if "my age is" in query_lower:
                age = query_lower.split("my age is")[1].strip().split()[0]
                self.store_personal_fact(user, "age", age)
                return f"Got it, {user.get('name', '')}! I've noted that you're {age} years old."
                
            if "tell me my age" in query_lower or "how old am i" in query_lower:
                age = self.get_personal_fact(user, "age")
                if age:
                    return f"You told me you're {age} years old."
                return "I don't have your age information. Could you tell me how old you are?"
            
            # Handle preference-related queries - store user preferences
            if is_preference and is_personal:
                # Try to identify what the user likes/dislikes
                sentiment = TextBlob(query).sentiment.polarity
                words = query_lower.split()
                
                for preference_word in ["like", "love", "enjoy", "prefer", "favorite"]:
                    if preference_word in words:
                        idx = words.index(preference_word)
                        if idx < len(words) - 1:
                            potential_pref = " ".join(words[idx+1:])
                            # Clean up the preference
                            potential_pref = potential_pref.strip().rstrip(".!?")
                            if potential_pref and len(potential_pref) > 2:
                                # Store as a personal fact with the appropriate type
                                if preference_word == "favorite":
                                    self.store_personal_fact(user, f"favorite_{potential_pref.split()[0]}", potential_pref)
                                else:
                                    self.store_personal_fact(user, f"likes", potential_pref)
            
            # Handle data deletion
            if "delete my data" in query_lower:
                self.handle_data_deletion(user)
                return ""
                
            if "check my reminder" in query_lower or "any reminders" in query_lower:
                if not self.has_reminders(user):
                    return "You don't have any reminders scheduled at this time."
                return ""
                
            # Handle memory-specific queries
            if is_memory_related:
                # Prioritize memory retrieval with higher limit
                memories = self.retrieve_relevant_memories(user, query, limit=7)
                if memories:
                    # For memory-related queries, we'll create a special context with more memories
                    context = self._prepare_conversation_context(user, query) 
                    # Emphasize the memory aspect in the prompt
                    response = self._call_llm_api(user, query, context, memory_emphasis=True)
                    return self._post_process_response(response, user)
                    
            # Standard query handling with improved context
            context = self._prepare_conversation_context(user, query)
            response = self._call_llm_api(user, query, context)
            return self._post_process_response(response, user)
            
        except Exception as e:
            print(f"Response Generation Error: {str(e)}")
            return random.choice([
                "I'm having trouble with that request. Could you try again?",
                "I encountered an issue processing that. Let me try again.",
                "There was a temporary problem. Could you rephrase your question?"
            ])

    def _call_llm_api(self, user: Dict, query: str, context: str, memory_emphasis=False) -> str:
        """Call the Together API to generate a response with improved context handling."""
        # Create prompt with emphasis on contextual understanding
        memory_instruction = ""
        if memory_emphasis:
            memory_instruction = """
7. Pay special attention to the user's memories and previous conversations
8. When recalling information the user has told you before, reference it clearly"""
            
        prompt = f"""You are a friendly AI assistant named Wiztron. You're talking to {user.get('name', 'the user')}.

Context:
{context}

Current conversation:
User: {query}

Guidelines:
1. Respond naturally and conversationally
2. Keep responses concise (1-2 sentences max)
3. IMPORTANT: Maintain context from previous conversations
4. Remember past interactions with the user when relevant
5. Use {user.get("language_preference", "English")} language
6. Personalize your response based on what you know about the user{memory_instruction}

Response:"""
    
        try:
            client = Together(api_key=TOGETHER_API_KEY)
            response = client.chat.completions.create(
                model="meta-llama/Llama-3.3-70B-Instruct-Turbo-Free",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=150,
                temperature=0.7,
                top_p=0.9,
                frequency_penalty=0.5,
                presence_penalty=0.5
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            print(f"LLM API Error: {str(e)}")
            return "I'm having some trouble responding right now. Could you try again?"

    def _post_process_response(self, response: str, user: Dict) -> str:
        """Clean up and personalize the generated response."""
        # Remove any LLM artifacts
        response = response.split("Response:")[-1].strip()
        
        # Personalize with user's name if available
        if user.get("name") and len(response.split()) < 20:  # Only for short responses
            if random.random() < 0.3:  # 30% chance to personalize
                response = f"{user['name']}, {response[0].lower() + response[1:]}"
        
        # Ensure proper punctuation
        if response and response[-1] not in {".", "!", "?"}:
            response += "."
        
        return response

    def update_conversation_log(self, user: Dict, query: str, response: str):
        """Update the user's conversation log with enhanced context and metadata."""
        try:
            # Get current log to determine if pruning is needed
            current_log = user.get("conversation_log", [])
            
            # Create richer context by adding sentiment and topics
            try:
                sentiment = TextBlob(query).sentiment.polarity  # -1 to 1 scale
                # Extract potential topics using keywords
                all_text = f"{query} {response}"
                potential_topics = []
                for word in set(all_text.lower().split()):
                    if len(word) > 4 and word not in ["about", "would", "could", "should", "there", "their", "what", "when", "where", "which", "while", "with"]:
                        potential_topics.append(word)
            except Exception as e:
                print(f"Context enrichment error: {e}")
                sentiment = 0
                potential_topics = []
            
            # Prepare new entry with enhanced vector embedding
            new_entry = {
                "query": query,
                "response": response,
                "timestamp": datetime.now(),
                "vector": self.memory_model.encode(f"{query} {response}").tolist(),
                "sentiment": sentiment,
                "topics": potential_topics[:5],  # Store top 5 potential topics
                "context": {
                    "time_of_day": datetime.now().strftime("%H:%M"),
                    "day_of_week": datetime.now().strftime("%A")
                }
            }
            
            # Keep more history - increase to 30 entries
            MAX_EXTENDED_HISTORY = 30
            
            # Check if we need to prune old entries
            if len(current_log) >= MAX_EXTENDED_HISTORY:
                # Remove the oldest entry
                users.update_one(
                    {"_id": user["_id"]},
                    {"$pop": {"conversation_log": -1}}  # -1 removes first element
                )
            
            # Add new entry
            users.update_one(
                {"_id": user["_id"]},
                {"$push": {"conversation_log": new_entry}}
            )
            
            # Update local user object
            if "conversation_log" not in user:
                user["conversation_log"] = []
            user["conversation_log"].append(new_entry)
            
        except Exception as e:
            print(f"Conversation Log Error: {str(e)}")
            # Fallback to simple logging without vector
            try:
                users.update_one(
                    {"_id": user["_id"]},
                    {"$push": {"conversation_log": {
                        "query": query,
                        "response": response,
                        "timestamp": datetime.now()
                    }}}
                )
            except Exception as e:
                print(f"Fallback Log Update Failed: {str(e)}")

    def update_memory(self, user: Dict, text: str, importance: float = 1.0):
        """Update the user's memory with enhanced semantic understanding."""
        try:
            # Extract key facts or information from the text
            blob = TextBlob(text)
            sentences = blob.sentences
            
            # Process each sentence as a potential memory unit
            for sentence in sentences:
                if len(str(sentence)) < 5:  # Skip very short sentences
                    continue
                    
                # Calculate an importance score based on keyword presence
                local_importance = importance
                key_terms = ["remember", "important", "forget", "need", "must", "always", "never", "favorite", "like", "love", "hate", "prefer"]
                if any(term in str(sentence).lower() for term in key_terms):
                    local_importance *= 1.5  # Boost importance for sentences with key terms
                
                # Generate embedding with importance weighting
                embedding = self.memory_model.encode(str(sentence)).tolist()
                if local_importance != 1.0:
                    embedding = [x * local_importance for x in embedding]
                
                # Check if this is similar to existing memories to avoid duplicates
                is_duplicate = False
                if user["_id"] in self.memory_cache:
                    query_vector = torch.tensor(embedding)
                    for existing_memory in self.memory_cache[user["_id"]]:
                        if "embedding" in existing_memory:
                            existing_vector = torch.tensor(existing_memory["embedding"])
                            similarity = torch.nn.functional.cosine_similarity(
                                query_vector.unsqueeze(0),
                                existing_vector.unsqueeze(0)
                            ).item()
                            
                            if similarity > 0.85:  # High threshold for duplication
                                # Instead of skipping, update the importance and access count
                                users.update_one(
                                    {"_id": user["_id"], "memories.text": existing_memory["text"]},
                                    {
                                        "$inc": {"memories.$.access_count": 1, "memories.$.importance": 0.1},
                                        "$set": {"memories.$.last_accessed": datetime.now()}
                                    }
                                )
                                is_duplicate = True
                                break
                
                if is_duplicate:
                    continue
                
                # Create memory entry with metadata
                memory_entry = {
                    "text": str(sentence),
                    "embedding": embedding,
                    "timestamp": datetime.now(),
                    "importance": local_importance,
                    "access_count": 0,
                    "last_accessed": datetime.now(),
                    "context": {
                        "from_conversation": True,
                        "original_text": text[:100] + ("..." if len(text) > 100 else ""),
                        "sentiment": sentence.sentiment.polarity
                    }
                }
                
                # Update database
                users.update_one(
                    {"_id": user["_id"]},
                    {
                        "$push": {"memories": memory_entry},
                        "$inc": {"memory_version": 1}  # Track memory changes
                    }
                )
                
                # Update local memory cache
                if user["_id"] not in self.memory_cache:
                    self.memory_cache[user["_id"]] = []
                self.memory_cache[user["_id"]].append(memory_entry)
            
        except Exception as e:
            print(f"Memory Update Error: {str(e)}")
            # Fallback to simple text storage
            try:
                users.update_one(
                    {"_id": user["_id"]},
                    {"$push": {"memories": {"text": text, "timestamp": datetime.now()}}}
                )
            except Exception as e:
                print(f"Fallback Memory Update Failed: {str(e)}")
                
    def retrieve_relevant_memories(self, user: Dict, query: str, limit=3):
        """Retrieve memories relevant to the current query using semantic search."""
        try:
            # Get all memories for this user
            user_memories = user.get("memories", [])
            if not user_memories:
                return []
                
            # If we have a local cache, use it instead
            if user["_id"] in self.memory_cache:
                user_memories = self.memory_cache[user["_id"]]
            
            # Create query embedding
            query_embedding = self.memory_model.encode(query)
            
            # Calculate similarity with all memories
            similarities = []
            for memory in user_memories:
                if "embedding" in memory:
                    memory_vector = torch.tensor(memory["embedding"])
                    similarity = torch.nn.functional.cosine_similarity(
                        torch.tensor(query_embedding).unsqueeze(0),
                        memory_vector.unsqueeze(0)
                    ).item()
                    
                    # Apply importance and recency weighting
                    importance_factor = memory.get("importance", 1.0)
                    recency_factor = 1.0
                    if "timestamp" in memory:
                        hours_old = (datetime.now() - memory["timestamp"]).total_seconds() / 3600
                        recency_factor = math.exp(-0.01 * hours_old)  # Gentle decay based on age
                    
                    # Access count bonus (frequently accessed memories are more important)
                    access_bonus = min(memory.get("access_count", 0) * 0.05, 0.5)  # Up to 0.5 bonus
                    
                    weighted_similarity = similarity * importance_factor * (recency_factor + access_bonus)
                    similarities.append((memory, weighted_similarity))
            
            # Sort by weighted similarity
            similarities.sort(key=lambda x: x[1], reverse=True)
            
            # Return top relevant memories
            relevant_memories = [mem["text"] for mem, _ in similarities[:limit]]
            
            # Update access count for retrieved memories
            for memory, _ in similarities[:limit]:
                if "text" in memory:
                    users.update_one(
                        {"_id": user["_id"], "memories.text": memory["text"]},
                        {"$inc": {"memories.$.access_count": 1}, "$set": {"memories.$.last_accessed": datetime.now()}}
                    )
            
            return relevant_memories
            
        except Exception as e:
            print(f"Memory Retrieval Error: {str(e)}")
            return []

    def _prepare_conversation_context(self, user: Dict, query: str) -> str:
        """Prepare comprehensive context using semantic similarity for better understanding."""
        # Get all conversation history
        conversation_history = user.get("conversation_log", [])
        relevant_history = []
        
        # Use semantic similarity for better context understanding
        if conversation_history:
            try:
                # Encode the current query using sentence transformer
                query_embedding = self.memory_model.encode(query)
                
                # Calculate similarities with all previous conversations
                similarities = []
                for entry in conversation_history:
                    # If the entry already has a vector, use it
                    if "vector" in entry:
                        entry_vector = torch.tensor(entry["vector"])
                    else:
                        # Otherwise, compute it on the fly
                        combined_text = f"{entry['query']} {entry['response']}"
                        entry_vector = torch.tensor(self.memory_model.encode(combined_text))
                    
                    # Calculate cosine similarity
                    similarity = torch.nn.functional.cosine_similarity(
                        torch.tensor(query_embedding).unsqueeze(0),
                        entry_vector.unsqueeze(0)
                    ).item()
                    
                    similarities.append((entry, similarity))
                
                # Sort by similarity score (descending)
                similarities.sort(key=lambda x: x[1], reverse=True)
                
                # Take top 3 most relevant conversations
                for entry, score in similarities[:3]:
                    if score > 0.2:  # Lower threshold for more context retrieval
                        relevant_history.append(
                            f"Previous Question: {entry['query']}\n"
                            f"Previous Answer: {entry['response']}\n"
                        )
            except Exception as e:
                print(f"Error in semantic similarity calculation: {e}")
                # Fallback to most recent conversations if semantic similarity fails
                for entry in conversation_history[-3:]:
                    relevant_history.append(
                        f"Previous Question: {entry['query']}\n"
                        f"Previous Answer: {entry['response']}\n"
                    )
        
        # Retrieve semantically relevant memories
        relevant_memories = self.retrieve_relevant_memories(user, query, limit=5)
        
        # Add personal facts to context
        personal_facts = []
        if "personal_facts" in user:
            for fact in user["personal_facts"]:
                personal_facts.append(f"- {fact['type']}: {fact['value']}")
        
        # Build context with more details
        context = f"User Profile:\n- Name: {user.get('name', 'User')}\n"
        if personal_facts:
            context += "\nPersonal Facts:\n" + "\n".join(personal_facts) + "\n"
        
        # Include time information for time-aware responses
        current_time = datetime.now()
        context += f"\nCurrent Time: {current_time.strftime('%Y-%m-%d %H:%M')}\n"
        context += f"Day of Week: {current_time.strftime('%A')}\n"
        
        # Add memories section before conversation history
        if relevant_memories:
            context += "\nRelevant User Memories:\n"
            for i, memory in enumerate(relevant_memories):
                context += f"- {memory}\n"
        
        # Add conversation memory
        if relevant_history:
            context += "\nRelevant Conversation History:\n" + "\n".join(relevant_history)
        
        return context

    def _optimize_camera_settings(self):
        """Configure camera for optimal face detection performance with enhanced settings."""
        try:
            cap = cv2.VideoCapture(0)
            
            # Try to set optimal camera properties for face detection
            # Higher resolution for better detail
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)  # Full HD width 
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080) # Full HD height
            cap.set(cv2.CAP_PROP_FPS, 30)            # Higher frame rate
            
            # Adjust brightness and exposure for better face detection
            cap.set(cv2.CAP_PROP_BRIGHTNESS, 150)    # Brighter image (default is often 128)
            cap.set(cv2.CAP_PROP_CONTRAST, 60)       # Increased contrast (default is often 32)
            cap.set(cv2.CAP_PROP_SATURATION, 70)     # Slightly increased saturation
            cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0.75)# Auto exposure
            cap.set(cv2.CAP_PROP_AUTOFOCUS, 1)       # Enable autofocus if available
            
            # Capture a test frame to ensure settings were applied and to warm up the camera
            ret, test_frame = cap.read()
            
            # Check if settings were applied
            actual_width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
            actual_height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
            actual_fps = cap.get(cv2.CAP_PROP_FPS)
            
            # Display actual camera configuration
            print(f"Camera configured: {actual_width}x{actual_height} at {actual_fps} FPS")
            
            # Test the enhancement pipeline on the test frame if available
            if ret:
                try:
                    # Apply enhancements to test frame
                    enhanced = cv2.convertScaleAbs(test_frame, alpha=1.2, beta=10)
                    
                    # Apply quick denoising (faster version for startup)
                    enhanced = cv2.fastNlMeansDenoisingColored(enhanced, None, 5, 5, 3, 9)
                    
                    # Apply simple sharpening
                    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
                    enhanced = cv2.filter2D(enhanced, -1, kernel)
                    
                    # Test face detection on enhanced frame with simple parameters
                    face_locations = face_recognition.face_locations(enhanced, model="hog")
                    if face_locations:
                        print(f"Camera test successful: {len(face_locations)} faces detected in test frame")
                    else:
                        print("Camera test successful but no faces detected in test frame")
                        
                except Exception as enhance_err:
                    print(f"Enhancement test error (non-critical): {enhance_err}")
            
            cap.release()
            return True
        except Exception as e:
            print(f"Camera optimization error: {e}")
            return False

    def _provide_face_detection_guidance(self, face_locations=None, frame=None):
        """Analyze potential face detection issues and provide guidance to the user."""
        if face_locations:
            # We have faces, but check if they're too small
            face_sizes = [(loc[2] - loc[0]) * (loc[1] - loc[3]) for loc in face_locations]
            avg_face_size = sum(face_sizes) / len(face_sizes)
            
            # Check if faces are too small (likely too far away)
            if avg_face_size < 5000:  # Threshold for "too small"
                self.speak("I can see you, but you appear to be too far away. Please move closer.", force=True)
                return False
            return True
            
        # No faces detected, analyze potential issues
        if frame is not None:
            # Check brightness issues
            avg_brightness = np.mean(frame)
            if avg_brightness < 50:  # Too dark
                self.speak("The lighting appears to be too dark. Please turn on more lights or adjust your position.", force=True)
            elif avg_brightness > 200:  # Too bright
                self.speak("The image appears to be overexposed. Try reducing direct light on your face.", force=True)
            else:
                # If lighting seems OK, probably just positioning
                self.speak("I'm having trouble seeing your face. Please position yourself directly in front of the camera.", force=True)
        else:
            # Generic guidance if no frame is available
            self.speak("I'm having trouble detecting your face. Please ensure you're directly facing the camera with good lighting.", force=True)
            
        return False

    def run(self):
        """Main execution loop with proper error handling and cleanup."""
        try:
            print("✅ System Ready")
            # Optimize camera at startup
            self._optimize_camera_settings()
            self.speak("System Ready")
            
            while True:
                try:
                    self.spline.update_state("idle")
                    
                    # User recognition with improved retry logic
                    retry_count = 0
                    max_retries = 5  # Increased from 3 to 5 for better chances
                    
                    # Enhanced recognition loop with guidance
                    while retry_count < max_retries:
                        print("👁️ Looking for user...")
                        
                        # For diagnostic purposes, on later attempts, capture a frame
                        # to analyze lighting and positioning issues
                        diagnostic_frame = None
                        face_locations = None
                        
                        if retry_count >= 2:
                            try:
                                # Capture a frame for analysis if we've had multiple failures
                                cap = cv2.VideoCapture(0)
                                cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
                                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
                                ret, diagnostic_frame = cap.read()
                                cap.release()
                                
                                if ret:
                                    # Quick analysis to see if we can detect any faces
                                    face_locations = face_recognition.face_locations(diagnostic_frame, model="hog")
                            except Exception as diag_err:
                                print(f"Diagnostic frame error: {diag_err}")
                        
                        # Try to recognize user
                        user = self.recognize_user()
                        if user:
                            break
                        
                        retry_count += 1
                        if retry_count < max_retries:
                            # Provide tailored guidance based on diagnostic data
                            if retry_count >= 2:
                                self._provide_face_detection_guidance(face_locations, diagnostic_frame)
                            elif retry_count == 1:
                                self.speak("Please position yourself clearly in front of the camera")
                            else:
                                self.speak("Please try again")
                            
                            # Short pause to allow user to reposition
                            time.sleep(2 if retry_count >= 2 else 1)
                    
                    if not user:
                        print("❌ User recognition failed")
                        self.speak("I'm having trouble recognizing you. Let's try again in a moment.")
                        time.sleep(3)  # Give a longer pause before retrying the whole process
                        continue
                    
                    self.current_user = user
                    print(f"👤 User: {user['name']}")
                    self.speak(f"Welcome {user['name']}")
                    
                    # Inner interaction loop
                    while True:
                        try:
                            # Check inactivity and handle sleep mode
                            if self.check_inactivity():
                                query = self.listen()
                                if not query:
                                    continue
                            
                            # Check reminders with error handling
                            try:
                                self.check_reminders(user)
                            except Exception as e:
                                print(f"Reminder error: {str(e)}")
                            
                            # Main interaction
                            query = self.listen()
                            if not query:
                                continue
                            
                            # Handle exit commands
                            if any(word in query.lower() for word in ["exit", "goodbye", "quit", "bye"]):
                                print("👋 User exit")
                                self.speak("Goodbye!")
                                if user["_id"] in self.active_users:
                                    self.active_users[user["_id"]].save()
                                break
                            
                            # Generate and speak response (no 'generating' indicator)
                            response = self.generate_response(user, query)
                            if response:
                                self.speak(response)
                                self.update_conversation_log(user, query, response)
                                self.update_memory(user, f"{query}\n{response}")
                            
                        except sr.RequestError as e:
                            print(f"Recognition service error: {str(e)}")
                            self.speak("I'm having trouble hearing you. Please try again.")
                            continue
                        except sr.UnknownValueError:
                            print("Speech not understood")
                            continue
                        except Exception as e:
                            print(f"Error: {str(e)}")
                            self.spline.update_state("idle")
                            continue
                
                except KeyboardInterrupt:
                    raise
                except Exception as e:
                    print(f"System error: {str(e)}")
                    self.speak("System needs to restart")
                    self.spline.update_state("idle")
                    time.sleep(1)
                    
        except KeyboardInterrupt:
            print("Shutting down...")
        except Exception as e:
            print(f"Fatal error: {str(e)}")
        finally:
            # Cleanup
            try:
                print("Shutting down...")
                self.speak("Shutting down safely")
                if self.current_user and self.current_user["_id"] in self.active_users:
                    self.active_users[self.current_user["_id"]].save()
                self.cleanup()
            except Exception as e:
                print(f"Cleanup error: {str(e)}")

    def cleanup(self):
        """Clean up resources"""
        try:
            # Clean up PyTorch resources
            for memory_core in self.active_users.values():
                memory_core.save()
                del memory_core
            torch.cuda.empty_cache()
            
            # Clean up audio resources
            self.pyttsx3_engine.stop()
            if mixer.get_init():
                mixer.quit()
                
            # Close video capture if open
            cv2.destroyAllWindows()
            
            # Clean up Spline resources
            if hasattr(self, 'spline'):
                self.spline.cleanup()
            
        except Exception as e:
            print(f"Cleanup error: {str(e)}")

if __name__ == "__main__":
    ai = None
    try:
        ai = AICompanion()
        ai.run()
    except Exception as e:
        print(f"Startup error: {str(e)}")
    finally:
        if ai:
            try:
                ai.cleanup()
            except:
                pass