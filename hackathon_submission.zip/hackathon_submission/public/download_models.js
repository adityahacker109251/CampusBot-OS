// Script to download face-api.js models
const fs = require('fs');
const path = require('path');
const https = require('https');
const { promisify } = require('util');

const mkdir = promisify(fs.mkdir);
const access = promisify(fs.access);
const writeFile = promisify(fs.writeFile);

// Base URL for models
const MODELS_BASE_URL = 'https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/weights';

// Models to download
const MODELS = [
    // TinyFaceDetector
    'tiny_face_detector_model-weights_manifest.json',
    'tiny_face_detector_model-shard1',
    
    // Age Gender Net
    'age_gender_model-weights_manifest.json',
    'age_gender_model-shard1',
    
    // Face Expression Net
    'face_expression_model-weights_manifest.json',
    'face_expression_model-shard1',
];

// Directory to save models
const MODELS_DIR = path.join(__dirname, 'models');

// Download a file
async function downloadFile(url, filePath) {
    return new Promise((resolve, reject) => {
        console.log(`Downloading ${url} to ${filePath}`);
        
        const file = fs.createWriteStream(filePath);
        https.get(url, response => {
            if (response.statusCode !== 200) {
                reject(new Error(`Failed to download ${url}, status code: ${response.statusCode}`));
                return;
            }
            
            response.pipe(file);
            file.on('finish', () => {
                file.close();
                console.log(`Downloaded ${filePath}`);
                resolve();
            });
        }).on('error', err => {
            fs.unlink(filePath, () => {}); // Delete file on error
            reject(err);
        });
    });
}

// Create directory if it doesn't exist
async function ensureDirectoryExists(dirPath) {
    try {
        await access(dirPath);
    } catch (err) {
        await mkdir(dirPath, { recursive: true });
        console.log(`Created directory: ${dirPath}`);
    }
}

// Download all models
async function downloadModels() {
    try {
        await ensureDirectoryExists(MODELS_DIR);
        
        // Download models in parallel
        const promises = MODELS.map(model => {
            const url = `${MODELS_BASE_URL}/${model}`;
            const filePath = path.join(MODELS_DIR, model);
            return downloadFile(url, filePath);
        });
        
        await Promise.all(promises);
        console.log('All models downloaded successfully!');
    } catch (err) {
        console.error('Error downloading models:', err);
    }
}

// Run the download
downloadModels(); 