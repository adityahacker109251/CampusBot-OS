import http.server
import socketserver
import os
import webbrowser
import json
import urllib.parse
import traceback
import sys
import signal
import time
import threading
import shutil
from http import HTTPStatus
from threading import Thread

# Configuration
PORT = 8000
DIRECTORY = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(DIRECTORY, "models")
RECONNECT_ATTEMPTS = 3

# Global state
latest_message = {
    "text": "",
    "state": "idle"
}

# Face detection state
face_data = {
    "mood": "neutral",
    "age": 0,
    "gender": "unknown",
    "detected": False
}

# Set up logging
def log(message, level="INFO"):
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{timestamp}] [{level}] {message}")

# Ensure the models directory exists
def ensure_models_directory():
    if not os.path.exists(MODELS_DIR):
        try:
            os.makedirs(MODELS_DIR)
            log(f"Created models directory at {MODELS_DIR}")
            return True
        except Exception as e:
            log(f"Error creating models directory: {e}", "ERROR")
            return False
    return True

class MessageHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        # Reduce verbosity of logs
        self.log_enabled = False
        super().__init__(*args, directory=DIRECTORY, **kwargs)
        
    def log_message(self, format, *args):
        # Only log if enabled
        if self.log_enabled:
            super().log_message(format, *args)
        
    def do_GET(self):
        """Handle GET requests"""
        try:
            # Handle update requests
            if self.path.startswith('/update'):
                self.handle_update()
            # Handle message retrieval
            elif self.path == '/get_message':
                self.handle_get_message()
            # Handle face data
            elif self.path == '/get_face_data':
                self.handle_get_face_data()
            # Default: serve static files
            else:
                super().do_GET()
        except Exception as e:
            log(f"Error handling GET request: {str(e)}", "ERROR")
            log(traceback.format_exc(), "ERROR")
            self.send_error(HTTPStatus.INTERNAL_SERVER_ERROR, str(e))
            
    def do_POST(self):
        """Handle POST requests"""
        try:
            # Handle model directory creation
            if self.path == '/create_models_dir':
                self.handle_create_models_dir()
            # Handle face data updates
            elif self.path == '/update_face_data':
                self.handle_update_face_data()
            else:
                self.send_error(HTTPStatus.NOT_FOUND)
        except Exception as e:
            log(f"Error handling POST request: {str(e)}", "ERROR")
            log(traceback.format_exc(), "ERROR")
            self.send_error(HTTPStatus.INTERNAL_SERVER_ERROR, str(e))
    
    def handle_update_face_data(self):
        """Update face detection data"""
        global face_data
        
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        
        try:
            data = json.loads(post_data.decode('utf-8'))
            face_data = {
                "mood": data.get("mood", "neutral"),
                "age": data.get("age", 0),
                "gender": data.get("gender", "unknown"),
                "detected": data.get("detected", False)
            }
            
            log(f"Updated face data: age={face_data['age']}, mood={face_data['mood']}, detected={face_data['detected']}")
            
            self.send_response(HTTPStatus.OK)
            self.send_header('Content-Type', 'text/plain')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(b'Face data updated')
        except json.JSONDecodeError:
            log("Invalid JSON in face data update", "ERROR")
            self.send_error(HTTPStatus.BAD_REQUEST, "Invalid JSON")
        
    def handle_get_face_data(self):
        """Return the latest face data as JSON"""
        try:
            self.send_response(HTTPStatus.OK)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps(face_data).encode())
        except Exception as e:
            log(f"Error handling get_face_data: {str(e)}", "ERROR")
            self.send_error(HTTPStatus.INTERNAL_SERVER_ERROR, str(e))
        
    def handle_create_models_dir(self):
        """Create the models directory if it doesn't exist"""
        success = ensure_models_directory()
        self.send_response(HTTPStatus.OK)
        self.send_header('Content-Type', 'text/plain')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        
        if success:
            self.wfile.write(b'Models directory created')
        else:
            self.wfile.write(b'Failed to create models directory')
        
    def handle_update(self):
        """Handle update requests from Python script"""
        global latest_message
        
        try:
            # Parse query parameters
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            
            # Get text and state
            text = params.get('text', [''])[0]
            state = params.get('state', ['idle'])[0]
            
            # Update latest message
            latest_message = {
                "text": urllib.parse.unquote(text),
                "state": state
            }
            
            # Log message (if not empty)
            if text:
                log(f"Updated message: {text[:50]}{'...' if len(text) > 50 else ''} (state: {state})")
            
            # Send response
            self.send_response(HTTPStatus.OK)
            self.send_header('Content-Type', 'text/plain')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(b'Updated')
        except Exception as e:
            log(f"Error handling update: {str(e)}", "ERROR")
            self.send_error(HTTPStatus.BAD_REQUEST, str(e))
        
    def handle_get_message(self):
        """Return the latest message as JSON"""
        try:
            self.send_response(HTTPStatus.OK)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(json.dumps(latest_message).encode())
        except Exception as e:
            log(f"Error handling get_message: {str(e)}", "ERROR")
            self.send_error(HTTPStatus.INTERNAL_SERVER_ERROR, str(e))

class ThreadedHTTPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    """Handle requests in a separate thread."""
    daemon_threads = True
    allow_reuse_address = True

def signal_handler(sig, frame):
    """Handle interrupt signals"""
    log("Received shutdown signal, stopping server...", "INFO")
    sys.exit(0)
    
def open_browser():
    """Open browser in a separate thread to avoid blocking"""
    time.sleep(1)  # Wait for server to start
    log("Opening connector in browser...")
    try:
        webbrowser.open(f"http://localhost:{PORT}/spline_connector.html")
    except Exception as e:
        log(f"Error opening browser: {str(e)}", "ERROR")

def start_server():
    """Start the HTTP server and open the connector in a browser."""
    # Create models directory at startup
    ensure_models_directory()
    
    # Register signal handlers for graceful shutdown
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    server = None
    for attempt in range(RECONNECT_ATTEMPTS):
        try:
            log(f"Starting server on port {PORT} (attempt {attempt+1}/{RECONNECT_ATTEMPTS})...")
            server = ThreadedHTTPServer(("", PORT), MessageHandler)
            log(f"Server started at http://localhost:{PORT}")
            log(f"Serving files from: {DIRECTORY}")
            log(f"Camera display available at: http://localhost:{PORT}/camera_display.html")
            
            # Start browser in a separate thread
            browser_thread = Thread(target=open_browser)
            browser_thread.daemon = True
            browser_thread.start()
            
            # Start serving
            server.serve_forever()
            break
        except OSError as e:
            if "Address already in use" in str(e) and attempt < RECONNECT_ATTEMPTS - 1:
                log(f"Port {PORT} is in use. Retrying in 2 seconds...", "WARNING")
                time.sleep(2)
            else:
                log(f"Failed to start server: {str(e)}", "ERROR")
                raise
                
if __name__ == "__main__":
    start_server() 